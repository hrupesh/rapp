@extends('layouts.app')
@section('content')
<div class="jumbotron">
    <h1 >{{$about}}</h1>
    <p >Welcome to the About page</p>
</div>
@endsection   