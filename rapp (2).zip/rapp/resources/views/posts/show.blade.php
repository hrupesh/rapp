@extends('layouts.app')
@section('content')
    <a href="/posts" class="btn btn-default">Go Back</a>
    <h1 >{{$post->title}}</h1>      
    <div class="container">
        {!!$post->body!!}
    </div>
    <small> Created at {{$post->created_at}}</small>
    <hr>
    <a href="/posts/{{$post->id}}/edit" class = "btn btn-default" role = "button">Edit</a>
       {!!Form::open(['action'=>['PostsController@destroy',$post->id],'method'=>'POST','class'=>'pull-right'])!!}
            {{Form::hidden('_method','Delete')}}
            {{Form::submit('Delete',['class'=>'btn btn-danger'])}}
           <!-- {{Form::date('name', \Carbon\Carbon::now())}} -->
        {!!Form::close()!!}
    
@endsection

    