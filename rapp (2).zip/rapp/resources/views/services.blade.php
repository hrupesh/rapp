@extends('layouts.app')
@section('content')
    <h1 align='center' >{{$title}}</h1>
    @if(count($provides)>0)
        <ul class="list-group">
            @foreach($provides as $ser)
                <li class="list-group-item">{{$ser}}</li>
            @endforeach
        </ul>
    @endif
@endsection